<?php

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (session_status() === PHP_SESSION_NONE) session_start();

require "db_conn.inc.php";
require "search_logs_functions.inc.php";
