<?php
include_once 'includes/header.php';
?>

<main>
	<h1>
		Home
	</h1>
</main>

<?php
include_once 'includes/footer.php';
?>