<?php
include_once 'includes/header.php';

if (isset($_SESSION['justLoggedIn'])) {
  echo $justLoggedInAlert;
  unset($_SESSION['justLoggedIn']);
}
if (isset($_SESSION['passResetSuccess'])) {
  echo $passResetSuccess;
  unset($_SESSION['passResetSuccess']);
}
?>

<main>
  <h1>
    Home
  </h1>
</main>

<?php
include_once 'includes/footer.php';
?>

<script>
  // Hide all alerts initially
  $("#success-alert").hide();
  $("#empty-input-alert").hide();
  $("#wrong-login-alert").hide();

  // Get the URL of the current page
  const url = window.location.href;

  // Check if the URL contains a specific string
  if (url.includes("message=loginsuccess")) {
    // Display the success-alert if the string is found
    $("#success-alert").show();
  }
</script>