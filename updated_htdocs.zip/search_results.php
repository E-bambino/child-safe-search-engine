<?php
include_once 'includes/header.php';
if (!isset($_SESSION['parentId'])) {
    header("location: /index.php");
    exit();
}
require_once "includes/search.inc.php";
?>

<main>
    <h1>
        Search Results
    </h1>
</main>

<?php
include_once 'includes/footer.php';
?>